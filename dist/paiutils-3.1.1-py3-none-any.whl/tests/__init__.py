from tests import (
    test_analytics, test_audio, test_autoencoder,
    test_evolution_algorithm, test_image,
    test_gan, test_neural_network,
    test_reinforcement, test_reinforcement_agents,
    test_util_funcs,
)

__version__ = '3.1.1'
