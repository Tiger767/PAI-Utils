from paiutils import (
    analytics, audio, autoencoder,
    evolution_algorithm, image,
    gan, neural_network,
    reinforcement, util_funcs
)

__version__ = '3.1.1'
