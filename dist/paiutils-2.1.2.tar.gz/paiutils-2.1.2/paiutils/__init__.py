from paiutils import (
    analytics, audio, autoencoder,
    evolution_algorithm, image,
    gan, neural_network,
    reinforcement
)

__version__ = '2.1.2'
