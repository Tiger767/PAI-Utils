"""
Author: Travis Hammond
Version: 12_28_2020
"""


def test_autoencoder_trainer():
    pass

def test_autoencoder_predictor():
    pass

def test_autoencoder_extra_decoder_trainer():
    pass

def test_vae_trainer():
    pass

def test_create_basic_dense_model():
    pass

def test_create_basic_conv2d_model():
    pass

def test_create_basic_conv1d_model():
    pass
