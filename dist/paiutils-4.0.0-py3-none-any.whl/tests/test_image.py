"""
Author: Travis Hammond
Version: 12_28_2020
"""


def test_rgb2bgr():
    pass

def test_bgr2rgb():
    pass

def test_bgr2hsv():
    pass

def test_hsv2bgr():
    pass

def test_bgr2hsl():
    pass

def test_hls2bgr():
    pass

def test_gray():
    pass

def test_resize():
    pass

def test_normalize():
    pass

def test_denormalize():
    pass

def test_pyr():
    pass

def test_load():
    pass

def test_save():
    pass

def test_increase_brightness():
    pass

def test_set_brightness():
    pass

def test_set_gamma():
    pass

def test_apply_clahe():
    pass

def test_equalize():
    pass

def test_rotate():
    pass

def test_hflip():
    pass

def test_vflip():
    pass

def test_translate():
    pass

def test_crop_rect():
    pass

def test_crop_rect_coords():
    pass

def test_shrink_sides():
    pass

def test_crop():
    pass

def test_pad():
    pass

def test_blend():
    pass

def test_zoom():
    pass

def test_transform_perspective():
    pass

def test_unsharp_mask():
    pass

def test_create_mask_of_colors_in_range():
    pass

def test_compute_color_ranges():
    pass

def test_create_magnitude_spectrum():
    pass

def test_freq_filter_image():
    pass

def test_create_histograms():
    pass

def test_histogram_back_projector():
    pass

def test_template_matecher():
    pass

def test_camera():
    pass
    
def test_lock_dict():
    pass

def test_windows():
    pass
