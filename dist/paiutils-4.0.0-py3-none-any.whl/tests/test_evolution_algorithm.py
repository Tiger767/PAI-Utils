"""
Author: Travis Hammond
Version: 12_28_2020
"""

def test_fitness():
    pass

def test_selection():
    pass

def test_crossover():
    pass

def test_mutation():
    pass

def test_size_mutation():
    pass

def test_evolution_algorithm():
    pass

def test_hyperparameter_tuner():
    pass
