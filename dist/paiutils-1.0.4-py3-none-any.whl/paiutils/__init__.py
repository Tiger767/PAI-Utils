from paiutils import (
    analytics, audio, autoencoder,
    evolution_algorithm, image,
    gan_network, neural_network,
    reinforcement
)

__version__ = '1.0.4'
