"""
Author: Travis Hammond
Version: 12_28_2020
"""


def test_environment():
    pass
 
def test_gym_wrapper():
    pass

def test_multiseq_agent_environment():
    pass
 
def test_policy():
    pass

def test_greedy_policy():
    pass

def test_ascetic_policy():
    pass

def test_stochastic_policy():
    pass

def test_noise_policy():
    pass

def test_uniform_noise_policy():
    pass

def test_temporal_noise_policy():
    pass

def test_decay():
    pass

def test_exponential_decay():
    pass

def test_linear_decay():
    pass

def test_memory():
    pass

def test_etd_memory():
    pass

def test_ring_memory():
    pass

def test_playingdata():
    pass

def test_agent():
    pass

def test_q_agent():
    pass

def test_pq_agent():
    pass

def test_memory_agent():
    pass
 
def test_dqn_agent():
    pass
 
def test_pg_agent():
    pass
 
def test_ddpg_agent():
    pass
