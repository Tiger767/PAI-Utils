"""
Author: Travis Hammond
Version: 12_28_2020
"""


def test_gan_trainer():
    pass

def test_gan_predictor():
    pass

def gani_trainer():
    pass
