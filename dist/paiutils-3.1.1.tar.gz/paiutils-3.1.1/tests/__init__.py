from paiutils import (
    test_analytics, test_audio, test_autoencoder,
    test_evolution_algorithm, image,
    test_gan, test_neural_network, test_vae,
    test_reinforcement, test_reinforcement_agents,
    test_util_funcs,
)

__version__ = '3.1.1'
