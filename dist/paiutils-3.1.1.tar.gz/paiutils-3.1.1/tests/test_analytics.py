"""
Author: Travis Hammond
Version: 12_28_2020
"""

def test_calculate_distribution_of_labels():
    pass

def test_create_label_ndx_groups():
    pass

def test_shrink_data():
    pass

def test_plot():
    pass

def test_isomap():
    pass

def test_locally_linear_embedding():
    pass

def test_mds():
    pass

def test_tsne():
    pass
