"""
Author: Travis Hammond
Version: 12_28_2020
"""


def test_convert_width_to_atype():
    pass

def test_convert_atype_to_width():
    pass

def test_change_rate():
    pass

def test_load():
    pass

def test_save():
    pass

def test_file_record():
    pass

def test_record():
    pass

def test_file_play():
    pass

def test_play():
    pass

def test_calc_duration():
    pass

def test_set_length():
    pass

def test_set_duration():
    pass

def test_for_each_frame():
    pass

def test_compute_spectrogram():
    pass

def test_convert_spectrogram_to_audio():
    pass


def test_compute_fbank():
    pass

def test_compute_mfcc():
    pass

def test_calc_rms():
    pass

def test_shift_pitch():
    pass

def test_set_power():
    pass

def test_adjust_speed():
    pass

def test_set_speed():
    pass

def test_adjust_volume():
    pass

def test_blend():
    pass

def test_plot():
    pass

def test_convert_audio_to_db()
    pass

def test_convert_power_to_db()
    pass

def test_convert_amplitude_to_db()
    pass

def test_trim_all():
    pass

def test_trim_sides():
    pass

def test_split():
    pass

def test_find_gaps():
    pass

def test_vad_trim_all():
    pass

def test_vad_trim_sides():
    pass

def test_vad_split():
    pass
