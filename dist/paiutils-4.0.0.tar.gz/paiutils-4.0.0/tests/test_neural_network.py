"""
Author: Travis Hammond
Version: 12_28_2020
"""


def test_trainer():
    pass

def test_predictor():
    pass

def test_dense():
    pass

def test_conv1d():
    pass

def test_conv2d():
    pass

def test_inception():
    pass
